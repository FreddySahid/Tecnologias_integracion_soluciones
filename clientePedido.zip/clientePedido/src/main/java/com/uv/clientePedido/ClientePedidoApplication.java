package com.uv.clientePedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientePedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientePedidoApplication.class, args);
	}

}
