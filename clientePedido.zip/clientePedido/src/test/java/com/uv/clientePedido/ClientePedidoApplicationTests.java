package com.uv.clientePedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientePedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
